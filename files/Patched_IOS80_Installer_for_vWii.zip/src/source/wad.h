s32 Wad_GetTMD_and_Certs(char *filename, void **ptmd, u32 *tmdlen, void **certs, u32 *certslen);
s32 Wad_Install(char *filename, bool installticket);
bool check_WAD(char *filename, u32 version, u32 revision);

